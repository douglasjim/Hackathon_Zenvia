module.exports = require('./src/oidc-client.js');
